/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mergesort;
import java.util.Arrays;
/**
 *
 * @author hp
 */



public class MergeSort {
    public int[] merge(int[] nums1, int[] nums2) {
        int[] sorted_nums = new int[nums1.length + nums2.length];

        // pointers for the two arrays
        int count_nums1 = 0;
        int count_nums2 = 0;

        int count = 0;
        while (count_nums1 < nums1.length && count_nums2 < nums2.length) {
            if (nums1[count_nums1] < nums2[count_nums2]) {
                sorted_nums[count] = nums1[count_nums1];
                count_nums1++;
                count++;
            } else if (nums2[count_nums2] <= nums1[count_nums1]) {
                sorted_nums[count] = nums2[count_nums2];
                count_nums2++;
                count++;
            }
        }

        // clean up for first array
        while (count_nums1 < nums1.length) {
            sorted_nums[count] = nums1[count_nums1];
            count++;
            count_nums1++;
        }

        // clean up for second array
        while (count_nums2 < nums2.length) {
            sorted_nums[count] = nums2[count_nums2];
            count++;
            count_nums2++;
        }

        return sorted_nums;
    }

    public int[] partition(int[] nums, int start, int stop) {
        int[] sub_nums = new int[stop - start];
        for (int i = start; i < stop; i++) {
            sub_nums[i % sub_nums.length] = nums[i];
        }
        return sub_nums;
    }

    public int[] mergeSort(int[] nums) {
        // base condition
        if (nums.length == 1)
            return nums;

        int mid = nums.length / 2;

        // partitioning and recursive call
        int[] nums1 = mergeSort(partition(nums, 0, mid));
        int[] nums2 = mergeSort(partition(nums, mid, nums.length));

        // combine and return
        return merge(nums1, nums2);
    }

    public static void main(String[] args) {
        MergeSort sort = new MergeSort();

        int[] nums = {5, 3, 12, 8, 2, 1, 6, 2, 11, 7, 10};
        int[] sorted = sort.mergeSort(nums);

        System.out.println(Arrays.toString(nums) + " ==> " + Arrays.toString(sorted));
    }

}
    

