/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayrandomempty;
  import java.util.Random;
/**
 *
 * @author hp
 */
public class Arrayrandomempty {
static int size;
static Random randomEntry = new Random();



public static void main(String[] args) {
int [] array = { 0, 1, 2, 3, 4, 5};

deliteEntries(array);


}

public static void deliteEntries(int[] array) {
size=array.length;
int[] ar = new int[size - 1];
System.out.println("Array:");
while (size > 0) {
    int index = randomEntry.nextInt(array.length);
    System.out.print( array[index]+" ");
   
    
    for (int i = 0; i < index; i++){
        ar[i] = array[i];
         
    }
    for (int i = index; i < size - 1; i++)
        ar[i] = array[i + 1];
        array = ar;
        
    System.out.println("at this level the size is :" +size);
    size--;
}

System.out.println();
System.out.println("Now the array is empty since the size is :"+size);


}
}

